<p align="center"><a href="https://mrsmartcs.com" target="_blank"><img src="./storage/app/public/icons/logo.svg" width="200"></a></p>

 <div align="center">
 <h1>Mr Smart Cleaning Services</h1>
 MrSmart is a cleaning company based in Kenya.

 </div>
