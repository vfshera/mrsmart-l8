<div>
    @if ($show)
        <div class="modal-wrapper ">

            <div class="modal ">
                Modal Here
            </div>
        </div>
    @endif
</div>
