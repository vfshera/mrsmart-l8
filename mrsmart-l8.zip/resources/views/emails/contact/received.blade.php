<x-mail-layout>

    You have received a new message from {{ $sender }}.<br>

    <br>

    Message: <br>

    {{ $msg }}

</x-mail-layout>
