<x-mail-layout>
    Hello {{ $name }}, <br>
    We have received your message.<br>
    Our representative will reach out to you soon.

</x-mail-layout>
