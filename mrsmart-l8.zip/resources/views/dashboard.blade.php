<x-admin-layout>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-primary/10 shadow-xl sm:rounded-lg p-10">
                Welcome to the Dashboard!
            </div>
        </div>
    </div>
</x-admin-layout>
