<?php return array (
  'messages' => 'App\\Http\\Livewire\\Messages',
  'modal' => 'App\\Http\\Livewire\\Modal',
  'settings' => 'App\\Http\\Livewire\\Settings',
);