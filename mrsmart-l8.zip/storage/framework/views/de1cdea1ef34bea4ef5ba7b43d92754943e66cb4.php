<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="mrsmart-container" x-data="{ open: false }">
        <div class="view-message-wrapper" x-cloak x-show="open" @click.away="open = false">

            <div class="view-message-modal">

                <header>
                    <p x-text="$wire.name"></p>
                    <span @click="open = false">&times;</span>
                </header>

                <p class="content" x-text="$wire.msg"></p>

            </div>

        </div>

        <div class="messages-page">

            <h1>Messages</h1>

            <hr>


            <div class="messages">

                <div class="message-header">
                    <div class="name">Name</div>
                    <div class="email">Email</div>
                    <div class="received">Received</div>
                    <div class="content">Content</div>
                </div>

                <hr>

                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="message"
                        wire:click="setMessage(<?php echo e($message->name); ?> , '<?php echo e($message->message); ?>' )"
                        @click="open = true">
                        <div class="name"><?php echo e($message->name); ?></div>
                        <div class="email"><?php echo e($message->email); ?></div>
                        <div class="received"><?php echo e(date('jS M Y H:i', strtotime($message->created_at))); ?></div>
                        <div class="content"><?php echo e($message->message); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH D:\PROJECTS\CODE\PHP\LARAVEL\mrsmart-l8\resources\views/livewire/messages.blade.php ENDPATH**/ ?>