<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="mrsmart-container">
        <div class=" site-settings-page">

            <h1>Site Settings </h1>

            <hr>

            <div class="settings">

                <div class="mono-settings">
                    <div class="setting">
                        <p class="name">Name</p>
                        <p class="value"><?php echo e($siteInfo->name); ?></p>
                    </div>

                    <div class="setting">
                        <p class="name">Location</p>
                        <p class="value"><?php echo e($siteInfo->location); ?></p>
                    </div>

                    <div class="setting">
                        <p class="name">Email</p>
                        <p class="value"><?php echo e($siteInfo->email); ?></p>
                    </div>

                    <div class="setting">
                        <p class="name">Phone</p>
                        <p class="value"><?php echo e($siteInfo->phone); ?></p>
                    </div>
                </div>


                <div class="group-settings">
                    <div class="settings-group">
                        <h3>Operating Days</h3>
                        <div class="setting">
                            <p class="name">From</p>
                            <p class="value"><?php echo e($siteInfo->operation_day_from); ?></p>
                        </div>
                        <div class="setting">
                            <p class="name">To</p>
                            <p class="value"><?php echo e($siteInfo->operation_day_to); ?></p>
                        </div>
                    </div>

                    <div class="settings-group">
                        <h3>Operating Hours</h3>
                        <div class="setting">
                            <p class="name">From</p>
                            <p class="value">

                                <?php if($settingField === 'operation_time_from'): ?>
                                    <input type="text" wire:model.debounce.500ms="settingValue"
                                        value="<?php echo e($siteInfo->operation_time_from); ?>">
                                <?php else: ?>
                                    <span data-field="Edit Operation Time"
                                        wire:click="setField('operation_time_from')"><?php echo e($siteInfo->operation_time_from); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="setting">
                            <p class="name">To</p>
                            <p class="value">
                                <?php if($settingField === 'operation_time_to'): ?>
                                    <input type="text" wire:model.debounce.500ms="settingValue"
                                        value="<?php echo e($siteInfo->operation_time_to); ?>">
                                <?php else: ?>
                                    <span data-field="Edit Operation Time"
                                        wire:click="setField('operation_time_to')"><?php echo e($siteInfo->operation_time_to); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH D:\PROJECTS\CODE\PHP\LARAVEL\mrsmart-l8\resources\views/livewire/settings.blade.php ENDPATH**/ ?>