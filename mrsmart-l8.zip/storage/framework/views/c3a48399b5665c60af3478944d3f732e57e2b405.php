<div>
    <?php if($show): ?>
        <div class="modal-wrapper ">

            <div class="modal ">
                Modal Here
            </div>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH D:\PROJECTS\CODE\PHP\LARAVEL\mrsmart-l8\resources\views/livewire/modal.blade.php ENDPATH**/ ?>