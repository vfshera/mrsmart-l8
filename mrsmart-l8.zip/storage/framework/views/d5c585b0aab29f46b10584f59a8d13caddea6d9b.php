<div class="input-group">
    <label for="<?php echo e(strtolower($label)); ?>"><?php echo e($label); ?></label>
    <?php $__errorArgs = [strtolower($label)];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="error"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input name="<?php echo e(strtolower($label)); ?>" type="<?php echo e($inputType); ?>" placeholder=" Enter <?php echo e(strtolower($label)); ?>"
        value="<?php echo e(old(strtolower($label))); ?>">
</div>
<?php /**PATH D:\PROJECTS\CODE\PHP\LARAVEL\mrsmart-l8\resources\views/components/form/input-field.blade.php ENDPATH**/ ?>