<?php if (isset($component)) { $__componentOriginal8a3e2de61d20ac3529b5ae4619a853c882c308c5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MailLayout::class, []); ?>
<?php $component->withName('mail-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    You have received a new message from <?php echo e($sender); ?>.<br>

    <br>

    Message: <br>

    <?php echo e($msg); ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a3e2de61d20ac3529b5ae4619a853c882c308c5)): ?>
<?php $component = $__componentOriginal8a3e2de61d20ac3529b5ae4619a853c882c308c5; ?>
<?php unset($__componentOriginal8a3e2de61d20ac3529b5ae4619a853c882c308c5); ?>
<?php endif; ?>
<?php /**PATH D:\PROJECTS\CODE\PHP\LARAVEL\mrsmart-l8\resources\views/emails/contact/received.blade.php ENDPATH**/ ?>