<?php if (isset($component)) { $__componentOriginal8a3e2de61d20ac3529b5ae4619a853c882c308c5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MailLayout::class, []); ?>
<?php $component->withName('mail-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    Hello <?php echo e($name); ?>, <br>
    We have received your message.<br>
    Our representative will reach out to you soon.

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a3e2de61d20ac3529b5ae4619a853c882c308c5)): ?>
<?php $component = $__componentOriginal8a3e2de61d20ac3529b5ae4619a853c882c308c5; ?>
<?php unset($__componentOriginal8a3e2de61d20ac3529b5ae4619a853c882c308c5); ?>
<?php endif; ?>
<?php /**PATH D:\PROJECTS\CODE\PHP\LARAVEL\mrsmart-l8\resources\views/emails/contact/sent.blade.php ENDPATH**/ ?>