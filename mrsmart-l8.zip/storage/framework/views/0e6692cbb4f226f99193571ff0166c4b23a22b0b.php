<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>


    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

    <?php echo \Livewire\Livewire::styles(); ?>



</head>

<body class="mrsmart">
    <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navbar::class, []); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>

    <main class="mrsmart-parent pt-12">
        <?php echo e($slot); ?>

    </main>


    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('modal', [])->html();
} elseif ($_instance->childHasBeenRendered('g1uO7RN')) {
    $componentId = $_instance->getRenderedChildComponentId('g1uO7RN');
    $componentTag = $_instance->getRenderedChildComponentTagName('g1uO7RN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('g1uO7RN');
} else {
    $response = \Livewire\Livewire::mount('modal', []);
    $html = $response->html();
    $_instance->logRenderedChild('g1uO7RN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php echo $__env->yieldPushContent('modals'); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>


    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
</body>

</html>
<?php /**PATH D:\PROJECTS\CODE\PHP\LARAVEL\mrsmart-l8\resources\views/components/admin-layout.blade.php ENDPATH**/ ?>