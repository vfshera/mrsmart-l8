<div class="mrsmart-container navbar " x-data="{ showMobileNav: false }">
    <a href="/">
        <img src="<?php echo e(url('storage/icons/logo.svg')); ?>" alt="Mr Smart Logo">
    </a>

    <div class="mobile-nav" x-cloak x-show="showMobileNav" x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0 scale-90" x-transition:enter-end="opacity-100 scale-100"
        x-transition:leave="transition ease-in duration-300" x-transition:leave-start="opacity-100 scale-100"
        x-transition:leave-end="opacity-0 scale-90">

        <img @click="showMobileNav = false" class="mobile-nav-close" src="<?php echo e(url('storage/icons/delete.svg')); ?>"
            alt="Mobile Menu Close">

        <ul>
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-link" @click=" showMobileNav = ! showMobileNav">
                    <a href="/">Home</a>
                </li>
                <li class="nav-link" @click=" showMobileNav = ! showMobileNav">
                    <a href="/">Services</a>
                </li>
                <li class="nav-link" @click=" showMobileNav = ! showMobileNav">
                    <a href="/">Contact</a>
                </li>
            <?php endif; ?>


            <?php if(auth()->guard()->check()): ?>
                <li class="nav-link" @click=" showMobileNav = ! showMobileNav">
                    <a href="/">Site</a>
                </li>
                <li class="nav-link" @click=" showMobileNav = ! showMobileNav">
                    <a href="#">Info</a>
                </li>
                <li class="nav-link  <?php echo e(request()->routeIs('messages') ? 'border-b border-accent' : ''); ?>"
                    @click=" showMobileNav = ! showMobileNav">
                    <a href="<?php echo e(route('messages')); ?>">Messages</a>
                </li>
                <li class="nav-link  <?php echo e(request()->routeIs('profile.show') ? 'border-b border-accent' : ''); ?>"
                    @click=" showMobileNav = ! showMobileNav">
                    <a href="<?php echo e(route('profile.show')); ?>">Profile</a>
                </li>



                <div class="user-info ">
                    <a class="user-name" href="<?php echo e(route('dashboard')); ?>">
                        <?php echo e(explode(' ', Auth::user()->name)[0]); ?></a>

                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn-logout">Logout</button>
                    </form>
                </div>
            <?php endif; ?>
        </ul>



    </div>

    <?php if(auth()->guard()->guest()): ?>

        <nav>
            <ul @click.outside="showMobileNav = false">
                <li class="nav-link">
                    <a href="<?php echo e(request()->routeIs('welcome') ? '/#hero' : '/'); ?>">Home</a>
                </li>
                <li class="nav-link">
                    <a href="/#services">Services</a>
                </li>
                <li class="nav-link">
                    <a href="/#contact">Contact</a>
                </li>
            </ul>



            <img @click="showMobileNav = true" class="mobile-nav-open" src="<?php echo e(url('storage/icons/menu.svg')); ?>"
                alt="Mobile Menu Open">

        </nav>


        <div class="call-number group">
            <img id="call-icon" src="storage/icons/phone.svg" alt="Call Us Icon">
            <a id="call-us" class="group-hover:text-white" href="tel:+254113350588">Call Us <?php echo e($siteInfo->phone); ?></a>
        </div>
    <?php endif; ?>


    <?php if(auth()->guard()->check()): ?>

        <span class="uppercase sm:hidden">Admin Dashboard</span>

        <nav class="admin-nav">
            <ul @click.outside="showMobileNav = false">
                <li class="nav-link">
                    <a href="/">Site</a>
                </li>
                <li class="nav-link <?php echo e(request()->routeIs('site-settings') ? 'border-b border-accent' : ''); ?>">
                    <a href="<?php echo e(route('site-settings')); ?>">Info</a>
                </li>
                <li class="nav-link  <?php echo e(request()->routeIs('messages') ? 'border-b border-accent' : ''); ?>">
                    <a href="<?php echo e(route('messages')); ?>">Messages</a>
                </li>
                <li class="nav-link  <?php echo e(request()->routeIs('profile.show') ? 'border-b border-accent' : ''); ?>">
                    <a href="<?php echo e(route('profile.show')); ?>">Profile</a>
                </li>
            </ul>



            <img @click="showMobileNav = true" class="mobile-nav-open" src="<?php echo e(url('storage/icons/menu.svg')); ?>"
                alt="Mobile Menu Open">

        </nav>


        <div class="user-info ">
            <a class="user-name" href="<?php echo e(route('dashboard')); ?>">
                Welcome,
                <?php echo e(explode(' ', Auth::user()->name)[0]); ?></a>

            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn-logout">Logout</button>
            </form>
        </div>
    <?php endif; ?>

</div>
<?php /**PATH D:\PROJECTS\CODE\PHP\LARAVEL\mrsmart-l8\resources\views/components/navbar.blade.php ENDPATH**/ ?>